# Hello, world!
#
# This is an example function named 'hello'
# which prints 'Hello, world!'.
#
# You can learn more about package authoring with RStudio at:
#
#   http://r-pkgs.had.co.nz/
#
# Some useful keyboard shortcuts for package authoring:
#
#   Install Package:           'Ctrl + Shift + B'
#   Check Package:             'Ctrl + Shift + E'
#   Test Package:              'Ctrl + Shift + T'

##################### Environmental Gradient and abundances along this gradient #####################

abund_env_grad <- function(nb_resource = 40, nb_consumer = 100, nb_location = 3,
                           mean_tol_env = 2, sd_tol_env = 10,
                           env_grad_min = 0, env_grad_max = 12) {
  ### resource gradient ###
  env_grad_resource <- array(0, dim = c(nb_resource, 2)) # two col, 1st: mean, 2nd: sd
  # Generate environmental optima for each species
  env_grad_resource[, 1] <- runif(nb_resource, min = env_grad_min, max = env_grad_max)
  # Generate random niche widths for each species
  env_grad_resource[, 2] <- abs(rnorm(nb_resource, mean = mean_tol_env, sd = sd_tol_env))


  ### Consumer gradient ###
  env_grad_consumer <- array(0, dim = c(nb_consumer, 2)) # two col, 1st: mean, 2nd: sd
  # Generate environmental optima for each species
  env_grad_consumer[, 1] <- runif(nb_consumer, min = env_grad_min, max = env_grad_max)
  # Generate random niche widths for each species
  env_grad_consumer[, 2] <- abs(rnorm(nb_consumer, mean = mean_tol_env, sd = sd_tol_env))

  ### Obtain abundances from a given position along the gradient ###
  site_coordonates <- seq(from = env_grad_min, to = env_grad_max, by = (env_grad_max - env_grad_min) / (nb_location - 1))

  ### Abundance Resource ###
  abund_resource <- array(0, c(nb_location, nb_resource))
  for (site in 1:nb_location) {
    for (resource in 1:nb_resource) {
      abund_resource[site, resource] <- dnorm(site_coordonates[site], mean = env_grad_resource[resource, 1], sd = env_grad_resource[resource, 2])
    }
  }

  ### Abundance Consumer ###
  abund_consumer <- array(0, c(nb_location, nb_consumer))
  for (site in 1:nb_location) {
    for (consumer in 1:nb_consumer) {
      abund_consumer[site, consumer] <- dnorm(site_coordonates[site], mean = env_grad_consumer[consumer, 1], sd = env_grad_consumer[consumer, 2])
    }
  }

  ### Results ###
  abundance <- list(
    abundance_resource = abund_resource,
    abundance_consumer = abund_consumer
  )
  return(abundance)
}

##################### Trait matching matrix #####################

trait_match_mat <- function(le_grad = 100, ratio_grad = 0.8,
                            buffer = 1,
                            mean_tol = 2, sd_tol = 10,
                            nb_resource = 40, nb_consumer = 100) {
  ### Initialize the gradient for axis 2 ###
  # The length of the second gradient is a fraction of the length of the first gradient
  gradmin2 <- (1 - ratio_grad) / 2 * le_grad
  gradmax2 <- le_grad - (1 - ratio_grad) / 2 * le_grad
  # For the columns, we include a buffer that is also on axis 2
  # (if buffer = 0 then gradmin/max2_buffer and gradmin/max2 are equal)
  gradmin2_buffer <- -buffer + gradmin2
  gradmax2_buffer <- buffer + gradmax2

  ### Environment/resource species trait gradient ###
  # Initialize empty trait/environment values matrix
  x <- matrix(0, nrow = nb_resource, ncol = 2)
  # For each site, generate an environmental gradient value at random (uniform) (and sort them)
  x[, 1] <- sort(runif(nb_resource, min = 0, max = le_grad))
  x[, 2] <- runif(nb_resource, min = gradmin2, max = gradmax2)

  ### Species niche/consumer niche ###
  # Initialize an array for species optima and tolerances
  # The array has last dimension 2 (one for each trait)
  p <- array(0, dim = c(nb_consumer, 2, 2))

  # Fill array p

  # -> first dimension
  # Generate environmental optima for each species
  p[, 1, 1] <- runif(nb_consumer, min = 0 - buffer, max = le_grad + buffer)
  # Generate random niche widths for each species
  p[, 2, 1] <- abs(rnorm(nb_consumer, mean = mean_tol, sd = sd_tol))

  # -> second dimension
  p[, 1, 2] <- runif(nb_consumer,
                     min = gradmin2_buffer,
                     max = gradmax2_buffer
  )
  p[, 2, 2] <- abs(rnorm(nb_consumer, mean = mean_tol, sd = sd_tol))

  ### Probability matrix (only matching) ###
  # Initialize empty community matrix
  p_matching <- matrix(0, nrow = nrow(x), ncol = nb_consumer)

  for (i in 1:nrow(x)) {
    for (j in 1:nb_consumer) {
      # Fill each cell with a "presence probability" or an "interaction probability"
      # from a multivariate normal law depending on:
      # - the matching between resource species trait and consumer species trait
      # - the matching between the site environmental value and the species niche optimum on this gradient
      p_matching[i, j] <- mvtnorm::dmvnorm(x[i, ] - p[j, 1, ], sigma = diag(p[j, 2, ]^2))
    }
  }
  # Transform negative values to zero probability
  p_matching <- ifelse(p_matching > 0, p_matching, 0)

  # Make columns a proba distribution
  # - each species (column) is distributed in sites following a probability of choosing this site
  # - each consumer (column) chooses the resource according to a given proba of presence
  p_matching <- sweep(p_matching, 2, STATS = apply(p_matching, 2, sum), FUN = "/")

  # Quick patch (in case there are species with zero obs that became NA at the division step)
  p_matching[is.na(p_matching)] <- 0

  ### Results ###
  return(p_matching)
}

##################### Mix abundance and trait matching #####################

int_count_th <- function(location, abund_resource, abund_consumer, p_matching, delta = 1) {
  ### Theoretical interaction count (based on abundances) ###
  # This code makes sense only for interaction matrices because the abundance of
  # resource species is a limiting factor here.
  # It makes less sense in the context of species x sites association, unless we consider
  # resources in the different sites are limited and a site has a limited number of species.
  prop_row <- abund_resource[location, ] / sum(abund_resource[location, ]) # Get the proportion of each plant (its "availability")
  ab_neutral <- prop_row %*% t(abund_consumer[location, ]) # Get the predicted abundance -> the birds
  # choose a plant only based on its availability
  # Each bird abundance is exactly abund_consumer and the plants abundances are proportional to
  # abund_resource

  ### Probability matrix (matching and abundance) ###
  # these theoretical abundances of interactions must then be confronted to the probability of interactions
  ab_mix <- ab_neutral * p_matching^delta # We multiply expected interaction number by trait matching
  # Create a vector of probabilities that takes into account the matching
  p_mix <- ab_mix / sum(ab_mix)
  p_mix[is.na(p_mix)] <- 0 # Handle divisions per zero

  ### Results ###
  return(p_mix)
}


##################### Master function #####################

env_grad_netw <- function(nb_resource = 40, nb_consumer = 100, nb_location = 3,
                          mean_tol_env = 2, sd_tol_env = 10,
                          env_grad_min = 0, env_grad_max = 12,
                          le_grad = 100, ratio_grad = 0.8,
                          buffer = 1,
                          mean_tol = 2, sd_tol = 10,
                          delta = 1) {
  abundance <- abund_env_grad(
    nb_resource = nb_resource, nb_consumer = nb_consumer, nb_location = nb_location,
    mean_tol_env = mean_tol_env, sd_tol_env = sd_tol_env,
    env_grad_min = env_grad_min, env_grad_max = env_grad_max
  )
  trait <- trait_match_mat(
    le_grad = le_grad, ratio_grad = ratio_grad,
    buffer = buffer,
    mean_tol = mean_tol, sd_tol = sd_tol,
    nb_resource = nb_resource, nb_consumer = nb_consumer
  )
  th_env_netw <- list()
  for (i in 1:nb_location) {
    th_env_netw[[i]] <- int_count_th(i, abund_resource = abundance$abundance_resource, abund_consumer = abundance$abundance_consumer, p_matching = trait)
  }
  return(list(network = th_env_netw, abudance = abundance))
}

